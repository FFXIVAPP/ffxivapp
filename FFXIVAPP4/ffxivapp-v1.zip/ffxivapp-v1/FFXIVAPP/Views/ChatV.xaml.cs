﻿// FFXIVAPP
// ChatV.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for ChatV.xaml
    /// </summary>
    public partial class ChatV
    {
        public static ChatV View;

        public ChatV()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
