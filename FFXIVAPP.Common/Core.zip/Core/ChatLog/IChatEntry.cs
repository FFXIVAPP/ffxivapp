﻿// FFXIVAPP.Common
// IChatEntry.cs
// 
// © 2013 ZAM Network LLC

#region Usings

using System;

#endregion

namespace FFXIVAPP.Common.Core.ChatLog
{
    public interface IChatEntry
    {
        DateTime TimeStamp { get; set; }
        string Code { get; set; }
        string Line { get; set; }
        string Combined { get; set; }
        string Raw { get; set; }
        byte[] Bytes { get; set; }
        bool JP { get; set; }
    }
}
