﻿// FFXIVAPP
// LogVOptions.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for LogVOptions.xaml
    /// </summary>
    public partial class LogVOptions
    {
        public static LogVOptions View;

        public LogVOptions()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
