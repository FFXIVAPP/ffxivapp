﻿// FFXIVAPP.Common
// ChatLogWorker.cs
// 
// © 2013 ZAM Network LLC

#region Usings

using System.Threading;

#endregion

namespace FFXIVAPP.Common.Core.ChatLog
{
    // internal, not accessible by plugins
    public class ChatLogWorker : IChatLogWorker
    {
        public delegate void NewLineEventHandler(ChatLogEntry chatLogEntry);

        public event NewLineEventHandler OnNewLine = delegate { };

        public void RaiseLineEvent(ChatLogEntry chatLogEntry)
        {
            OnNewLine(chatLogEntry);
        }
    }
}
