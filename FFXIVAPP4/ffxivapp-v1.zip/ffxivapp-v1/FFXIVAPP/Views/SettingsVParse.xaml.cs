﻿// FFXIVAPP
// SettingsVParse.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for SettingsVParse.xaml
    /// </summary>
    public partial class SettingsVParse
    {
        public static SettingsVParse View;

        public SettingsVParse()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
