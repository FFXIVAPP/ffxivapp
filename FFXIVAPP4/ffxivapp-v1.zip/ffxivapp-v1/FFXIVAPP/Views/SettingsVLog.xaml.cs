﻿// FFXIVAPP
// SettingsVLog.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for SettingsVLog.xaml
    /// </summary>
    public partial class SettingsVLog
    {
        public static SettingsVLog View;

        public SettingsVLog()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
