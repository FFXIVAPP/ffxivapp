﻿// FFXIVAPP
// SettingsVApplication.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for SettingsVApplication.xaml
    /// </summary>
    public partial class SettingsVApplication
    {
        public static SettingsVApplication View;

        public SettingsVApplication()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
