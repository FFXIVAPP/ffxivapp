﻿// FFXIVAPP
// ParseVDebug.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for ParseVDebug.xaml
    /// </summary>
    public partial class ParseVDebug
    {
        public static ParseVDebug View;

        public ParseVDebug()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
