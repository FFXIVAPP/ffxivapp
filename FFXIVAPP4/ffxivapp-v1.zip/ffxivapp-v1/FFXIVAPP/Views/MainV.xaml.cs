﻿// FFXIVAPP
// MainV.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for MainV.xaml
    /// </summary>
    public partial class MainV
    {
        public static MainV View;

        public MainV()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
