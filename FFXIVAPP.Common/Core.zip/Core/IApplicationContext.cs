﻿// FFXIVAPP.Common
// IApplicationContext.cs
// 
// © 2013 ZAM Network LLC

#region Usings

using FFXIVAPP.Common.Core.ChatLog;

#endregion

namespace FFXIVAPP.Common.Core
{
    public interface IApplicationContext
    {
        IChatLogWorker ChatLogWorker { get; }
    }
}
