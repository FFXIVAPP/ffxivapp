﻿// FFXIVAPP
// ParseVBasic.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for ParseVBasic.xaml
    /// </summary>
    public partial class ParseVBasic
    {
        public static ParseVBasic View;

        public ParseVBasic()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
