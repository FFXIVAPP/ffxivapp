﻿// FFXIVAPP
// SettingsVLogColor.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Views
{
    /// <summary>
    ///     Interaction logic for SettingsVLogColor.xaml
    /// </summary>
    public partial class SettingsVLogColor
    {
        public static SettingsVLogColor View;

        public SettingsVLogColor()
        {
            InitializeComponent();
            // Insert code required on object creation below this point.
            View = this;
        }
    }
}
