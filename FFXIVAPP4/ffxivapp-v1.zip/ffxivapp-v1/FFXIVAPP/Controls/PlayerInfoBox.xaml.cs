﻿// FFXIVAPP
// PlayerInfoBox.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Controls
{
    /// <summary>
    ///     Interaction logic for PlayerInfoBox.xaml
    /// </summary>
    public partial class PlayerInfoBox
    {
        public PlayerInfoBox()
        {
            InitializeComponent();
        }
    }
}
