﻿// FFXIVAPP
// FlowDoc.xaml.cs
//  
// Created by Ryan Wilson.
// Copyright © 2007-2012 Ryan Wilson - All Rights Reserved

namespace FFXIVAPP.Controls
{
    /// <summary>
    ///     Interaction logic for FlowDoc.xaml
    /// </summary>
    public partial class FlowDoc
    {
        public FlowDoc()
        {
            InitializeComponent();
        }
    }
}
