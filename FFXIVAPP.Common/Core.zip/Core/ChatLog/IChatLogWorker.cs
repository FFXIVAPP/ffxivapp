﻿// FFXIVAPP.Common
// IChatLogWorker.cs
// 
// © 2013 ZAM Network LLC

namespace FFXIVAPP.Common.Core.ChatLog
{
    public interface IChatLogWorker
    {
        event ChatLogWorker.NewLineEventHandler OnNewLine;
        void RaiseLineEvent(ChatLogEntry chatLogEntry);
    }
}
